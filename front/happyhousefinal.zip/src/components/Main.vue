<template>
  <div>
    <h1>Happy House 메인 화면 입니다.!!</h1>
  </div>
</template>

<script>
export default {
  name: 'Main',
};
</script>

<style></style>
