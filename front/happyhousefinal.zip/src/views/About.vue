<template>
  <div class="about">
    <h1>Happy House</h1>
    <p>해피 하우스 입니다!!</p>
  </div>
</template>
<script>
export default {
  name: 'About',
};
</script>
